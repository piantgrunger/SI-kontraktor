dependencies = {
	layers: [
		{
			name: "../dojox/fx.js",
			dependencies: [
				"dojo.NodeList-fx",
				"dojox.fx.ext-dojo.NodeList",
				"dojox.fx",
				"dojo.fx.easing"
			]
		}
	],

	prefixes: [
		[ "dijit", "../dijit" ],
		[ "dojox", "../dojox" ],
		[ "themes", "../themes" ]
	]
};
